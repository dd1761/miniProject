package user.controller;

import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import board.bean.BoardDTO;
import community.service.CommunityService;
import video.bean.VideoDTO;
import video.service.VideoService;

@Controller
@RequestMapping(value="user")
public class UserController {
	@Autowired
	CommunityService communityService;
	
	@Autowired
	VideoService videoService;
	
	@GetMapping(value="playvideo")
	public String playvideo() {
		
		return "video/playvideo";
	}
	
	@GetMapping(value="channelForm")
	public String channelForm(Model model) {
		
		model.addAttribute("display","./channel/channelForm.jsp");
		return "index";
	}
	
	@GetMapping(value="boardList")
	public String boardList(Model model) {
		
		model.addAttribute("display","./channel/channelForm.jsp");
		model.addAttribute("display2","../board/boardList.jsp");
		return "index";
	}
	
	@PostMapping(value = "getBoardList")
	@ResponseBody
	public List<BoardDTO> getBoardList(){
		return communityService.getBoardList();
	}
	
	
	@PostMapping(value = "boardDelete")
	@ResponseBody
	public void boardDelete(@RequestParam(required = true) int board_id) {
		communityService.boardDelete(board_id);
	}
	
	@PostMapping(value = "boardUpdate")
	@ResponseBody
	public void boardUpdate(@RequestParam(required = true) String board_text, @RequestParam int board_id, @RequestParam int channel_id) {
		System.out.println(board_text + " " + board_id + " " + channel_id);
		communityService.boardUpdate(board_text, board_id, channel_id);
	}
	
	
	@PostMapping(value = "mainContainerVideo")
	@ResponseBody
	public List<VideoDTO> mainContainerVideo(){
		
		return videoService.mainContainerVideo();
	}
	
	@GetMapping(value = "videosearch")
	public String videosearch(@RequestParam String videotitle, Model model) {
		
		model.addAttribute("display", "");
		model.addAttribute("display5", "./search/videosearch.jsp");
		
		
		return "index";
	}
	
	@PostMapping(value = "searchVideo")
	@ResponseBody
	public List<VideoDTO> searchVideo(@RequestParam String videotitle){
		//index.js로 돌아가서 받아온 데이터를 가지고 searchvideo로 넘어가야함
		System.out.println(videotitle);
		return videoService.searchVideo(videotitle);
	}
	
//	@PostMapping(value = "boardLike")
//	@ResponseBody
//	public String boardLike() {
//		return communityService.boardLike();
//	}
	
//	- 얘네들을 board DTO에 만들어놓기 
//	channel - channel_profile_url
//	channel - channel_name
//  channel - channel_id
//	community_board - upload_date
//	community_board - board_text
//	like_count - community 글의 likesu - board_id, like_idd
//	comment - community 글의 comment su
//  user - user_id 
	
//	Select channel_profile_url, channel_name, channel_id from channel
//	
	// channel, community_board, like_count, comment의 연결고리 column은 board_id고, user 테이블과 
	
	
	
}











