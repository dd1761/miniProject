package user.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional //sql문의 커밋과 클로즈를 대신 해줌
public class UserDAOMyBatis implements UserDAO {
	
	
}
