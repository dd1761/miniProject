package community.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import board.bean.BoardDTO;
import board.dao.BoardDAO;

@Service
public class CommunityServiceImpl implements CommunityService {
	@Autowired
	private BoardDAO boardDAO;
	
	@Override
	public List<BoardDTO> getBoardList() {
		return boardDAO.getBoardList();
	}

	@Override
	public void boardDelete(int board_id) {
		boardDAO.boardDelete(board_id);
		
	}

	@Override
	public void boardUpdate(String board_text, int board_id, int channel_id) {
		boardDAO.boardUpdate(board_text, board_id, channel_id);
		
	}
	
	
}
