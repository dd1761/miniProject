package community.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import board.bean.BoardDTO;


public interface CommunityService {

	public List<BoardDTO> getBoardList();

	public void boardDelete(int board_id);

	public void boardUpdate(String board_text, int board_id, int channel_id);

}
