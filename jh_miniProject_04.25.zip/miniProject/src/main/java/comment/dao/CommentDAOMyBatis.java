package comment.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import comment.bean.CommentDTO;

@Repository
@Transactional
public class CommentDAOMyBatis implements CommentDAO {

	

}
