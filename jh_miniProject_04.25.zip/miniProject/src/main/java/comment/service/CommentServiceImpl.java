package comment.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import comment.bean.CommentDTO;
import comment.dao.CommentDAO;

public class CommentServiceImpl implements CommentService {

	
	

}
