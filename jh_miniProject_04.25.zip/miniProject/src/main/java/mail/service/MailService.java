package mail.service;

public interface MailService {

	String joinEmail(String email);

}
