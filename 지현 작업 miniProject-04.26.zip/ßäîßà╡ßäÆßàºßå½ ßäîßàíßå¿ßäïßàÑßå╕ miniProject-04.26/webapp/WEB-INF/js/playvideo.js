$(function(){
	$.ajax({
		type: 'post',
		url: '/miniProject/user/videoComment',
	});
});