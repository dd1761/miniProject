//$(function(){
//	var user_id = parseInt($('#user_id').val(), 10);
//	
//	$.ajax({
//		type: 'post',
//		url: '/miniProject/user/boardWrite',
//		data: 'user_id=' + user_id,
//		success: function(data){
//			console.log(data);
//		},
//		error: function(err){
//			console.log(err);
//		}
//	});
//});