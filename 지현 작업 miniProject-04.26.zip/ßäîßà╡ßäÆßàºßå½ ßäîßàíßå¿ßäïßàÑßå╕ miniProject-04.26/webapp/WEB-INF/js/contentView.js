//$(function(){
//    $.ajax({
//        type: 'post',
//        url: '/miniProject/user/getBoardView',
//        success: function(data){
//            console.log(JSON.stringify(data));
//            console.log(data);
//        },
//        error: function(err){
//        	console.log(err);
//        }
//    });
//});

var queryParams = new URLSearchParams(location.search);

var board_id = queryParams.get('board_id');

//가져온 값을 이용하여 필요한 처리를 수행합니다.
console.log(board_id);
            
            