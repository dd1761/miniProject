//$('#co').click(function(){
//   $.ajax({
//      type: 'post',
//      url: '/miniProject/user/boardList',
//      data: 'channel_id=' + $('#c_id').val(),
//      success: function(data){
//         
//      },
//      error: function(err){
//         console.log(err);
//      }
//   });
//});