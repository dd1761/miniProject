package channel.service;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

public interface ChannelService {

	@Bean
	public String display();

}
