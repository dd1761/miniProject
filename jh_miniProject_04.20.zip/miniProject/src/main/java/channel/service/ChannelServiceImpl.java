package channel.service;

public class ChannelServiceImpl implements ChannelService {

	@Override
	public String display() {
		return "channel/channelForm";
	}
}
