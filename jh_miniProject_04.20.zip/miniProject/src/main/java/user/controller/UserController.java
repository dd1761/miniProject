package user.controller;

import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import board.bean.BoardDTO;
import community.service.CommunityService;

@Controller
@RequestMapping(value="user")
public class UserController {
	@Autowired
	CommunityService communityService;
	
	@GetMapping(value="playvideo")
	public String playvideo() {
		
		return "video/playvideo";
	}
	
	@GetMapping(value="channelForm")
	public String channelForm(Model model) {
		
		model.addAttribute("display","./channel/channelForm.jsp");
		return "index";
	}
	
	@GetMapping(value="boardList")
	public String boardList(Model model) {
		
		model.addAttribute("display","./channel/channelForm.jsp");
		model.addAttribute("display2","../board/boardList.jsp");
		return "index";
	}
	
	@PostMapping(value = "getBoardList")
	@ResponseBody
	public List<BoardDTO> getBoardList(){
		return communityService.getBoardList();
	}
	
//	@PostMapping(value = "boardLike")
//	@ResponseBody
//	public String boardLike() {
//		return communityService.boardLike();
//	}
	
//	- 얘네들을 board DTO에 만들어놓기 
//	channel - channel_profile_url
//	channel - channel_name
//  channel - channel_id
//	community_board - upload_date
//	community_board - board_text
//	like_count - community 글의 likesu - board_id, like_idd
//	comment - community 글의 comment su
//  user - user_id 
	
//	Select channel_profile_url, channel_name, channel_id from channel
//	
	// channel, community_board, like_count, comment의 연결고리 column은 board_id고, user 테이블과 
	
	
}











