package video.dao;

public class VideoDAOMyBatis implements VideoDAO {

}
