package video.dao;

public interface VideoDAO {

}
