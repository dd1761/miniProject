package video.service;

public interface VideoService {

}
