package video.service;

public class VideoServiceImpl implements VideoService {

}
